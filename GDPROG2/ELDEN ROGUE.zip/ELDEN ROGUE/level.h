#pragma once

#include "structures.h"
#include "character_creation.h"
#include "title.h"
#include "shop.h"
#include "stddef.h"
#include "round_table.h"
#include "files.h"
#include "inventory.h"
#include "area.h"


void displayLevelup(Player* pPlayer,int nRune);
void processlevelup(Player* pPlayer);