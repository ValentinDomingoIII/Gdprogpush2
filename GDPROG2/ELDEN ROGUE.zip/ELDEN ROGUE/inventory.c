#include "inventory.h"

void displayInventory(Player* pPlayer)
{
    int i;
    printf("\nINVENTORY\n");
    for (i = 0; i < pPlayer->nInventorySize; i++) {
        printf("[%d] %s - HP: %d, STR: %d, DEX: %d, INT: %d, END: %d, FTH: %d\n",
               i + 1, pPlayer->inventory[i].weapon,
               pPlayer->inventory[i].nHp, pPlayer->inventory[i].nStr,
               pPlayer->inventory[i].nDex, pPlayer->inventory[i].nInt,
               pPlayer->inventory[i].nEnd, pPlayer->inventory[i].nFth);
    }
    printf("[0] Back\n");

    printf("Choose a weapon or press '0' to go back: ");
}

void processInventory(Player* pPlayer) {
    char cChoice;

    do {
        displayInventory(pPlayer);

        scanf(" %c", &cChoice);

        if (cChoice == '0') {
            return;
        }

        int index = cChoice - '1';
        if (index >= 0 && index < pPlayer->nInventorySize) {
            if (pPlayer->sStats.nDexterity >= pPlayer->inventory[index].nDex) {
                pPlayer->equippedWeapon = &pPlayer->inventory[index];
                printf("You have equipped %s\n", pPlayer->equippedWeapon->weapon);
            } else {
                printf("You do not have enough dexterity to equip %s\n", pPlayer->inventory[index].weapon);
            }
        } else {
            printf("Invalid choice\n");
        }
    } while (1);

    clear();  // Assuming clear() is a function to clear the screen
}
