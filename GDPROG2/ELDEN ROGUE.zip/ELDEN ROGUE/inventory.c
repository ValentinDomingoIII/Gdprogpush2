#include "inventory.h"

void displayInventory(Player* player)
{
    int i;
    printf("\nINVENTORY\n");
    for (i = 0; i < player->nInventorySize; i++) {
        printf("[%d] %s - HP: %d, STR: %d, DEX: %d, INT: %d, END: %d, FTH: %d\n",
               i + 1, player->inventory[i].weapon,
               player->inventory[i].nHp, player->inventory[i].nStr,
               player->inventory[i].nDex, player->inventory[i].nInt,
               player->inventory[i].nEnd, player->inventory[i].nFth);
    }
    printf("[0] Back\n");

    printf("Choose a weapon or press '0' to go back: ");
}

void processInventory(Player* player) {
    char cChoice;

    do {
        displayInventory(player);

        scanf(" %c", &cChoice);

        if (cChoice == '0') {
            return;
        }

        int index = cChoice - '1';
        if (index >= 0 && index < player->nInventorySize) {
            if (player->sStats.nDexterity >= player->inventory[index].nDex) {
                player->equippedWeapon = &player->inventory[index];
                printf("You have equipped %s\n", player->equippedWeapon->weapon);
            } else {
                printf("You do not have enough dexterity to equip %s\n", player->inventory[index].weapon);
            }
        } else {
            printf("Invalid choice\n");
        }
    } while (1);

    clear();  // Assuming clear() is a function to clear the screen
}
