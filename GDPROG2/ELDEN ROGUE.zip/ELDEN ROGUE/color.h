#pragma once

void greenText();
void greenTextBG();
void resetText();
void redText();
void blueText();
void yellowText();
void yellowTextBG();
void pinkText();
void grayText();
void grayTextBG();
void purpleText();
void whiteText();
void whiteTextBG();
void line();
void enemyFelled();
void greatEnemyFelled();
void youDied();
void credits();
void displayHealthbar(int nMaxHealth, int nCurrentHealth);
void runesObtained(int nRandom);
void enemySprite();
void clear();