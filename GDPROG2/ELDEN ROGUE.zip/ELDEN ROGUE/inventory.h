#pragma once

#include "structures.h"
#include "character_creation.h"
#include "round_table.h"
#include "title.h"
#include "shop.h"
#include "stddef.h"
#include "files.h"
#include "level.h"

void displayInventory(Player* player);
void processInventory(Player* player);