#pragma once

#include "character_creation.h"
#include "round_table.h"
#include "area.h"
#include "shop.h"

void runTitle(Player* player);
void displayTitle();
void processTitle(int* nInput, Player* player);
