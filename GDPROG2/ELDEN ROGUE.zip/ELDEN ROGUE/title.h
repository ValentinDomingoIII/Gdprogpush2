#pragma once

#include "character_creation.h"
#include "round_table.h"
#include "area.h"
#include "shop.h"

void runTitle(Player* pPlayer);
void displayTitle();
void processTitle(char* cInput, Player* pPlayer);
