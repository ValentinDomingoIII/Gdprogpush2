#include "level.h"

void displayLevelup(Player* pPlayer, int nRune)
{
    printf("\n\t\t\t\t\t\t\tLEVEL UP\n\n");
    printf("\t\t\t\t\t\t\t[1] Level up HEALTH\t[4] Level up STRENGTH\n");
    printf("\t\t\t\t\t\t\t[2] Level up ENDURANCE\t[5] Level up INTELLIGENCE\n");
    printf("\t\t\t\t\t\t\t[3] Level up DEXTERITY\t[6] Level up FAITH\n");

    printf("\n\t\t\t\t\t\t\t\t\t[0] BACK\n");
    printf("\n\t\t\t\t\t\t\t\x1b[38;5;11m Runes:\x1b[0m%d\n\n", pPlayer->nRunes);
    printf("\n\t\t\t\t\t\t\tLevel up cost: %d\n", nRune);
    printf("\n\t\t\t\t\t\t\tINPUT: ");
}

void processlevelup(Player* pPlayer) {
    char cChoice, cChoice2;
    int nRune = (pPlayer->nLevel * 100) / 2;

    do {
        nRune = (pPlayer->nLevel * 100) / 2;
        displayLevelup(pPlayer, nRune);
        scanf(" %c", &cChoice);

        switch (cChoice) {
            case '1':
                if (pPlayer->sStats.nHealth >= 50) {
                    printf("\nHealth is maxed out at %d", pPlayer->sStats.nHealth);
                } else {
                    printf("\nLevel up Health?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nHealth++;
                        printf("\nHealth increased to %d", pPlayer->sStats.nHealth);
                    }
                }
                break;

            case '2':
                if (pPlayer->sStats.nEndurance >= 50) {
                    printf("\nEndurance is maxed out at %d", pPlayer->sStats.nEndurance);
                } else {
                    printf("\nLevel up Endurance?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nEndurance++;
                        printf("\nEndurance increased to %d", pPlayer->sStats.nEndurance);
                    }
                }
                break;

            case '3':
                if (pPlayer->sStats.nDexterity >= 50) {
                    printf("\nDexterity is maxed out at %d", pPlayer->sStats.nDexterity);
                } else {
                    printf("\nLevel up Dexterity?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nDexterity++;
                        printf("\nDexterity increased to %d", pPlayer->sStats.nDexterity);
                    }
                }
                break;

            case '4':
                if (pPlayer->sStats.nStrength >= 50) {
                    printf("\nStrength is maxed out at %d", pPlayer->sStats.nStrength);
                } else {
                    printf("\nLevel up Strength?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nStrength++;
                        printf("\nStrength increased to %d", pPlayer->sStats.nStrength);
                    }
                }
                break;

            case '5':
                if (pPlayer->sStats.nIntelligence >= 50) {
                    printf("\nIntelligence is maxed out at %d", pPlayer->sStats.nIntelligence);
                } else {
                    printf("\nLevel up Intelligence?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nIntelligence++;
                        printf("\nIntelligence increased to %d", pPlayer->sStats.nIntelligence);
                    }
                }
                break;

            case '6':
                if (pPlayer->sStats.nFaith >= 50) {
                    printf("\nFaith is maxed out at %d", pPlayer->sStats.nFaith);
                } else {
                    printf("\nLevel up Faith?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(pPlayer)) {
                        pPlayer->sStats.nFaith++;
                        printf("\nFaith increased to %d", pPlayer->sStats.nFaith);
                    }
                }
                break;

            case '0':
                clear();  // Assuming clear() is a function to clear the screen
                break;

            default:
                printf("\nInvalid choice. Please select a valid option.\n");
                break;
        }
    } while (cChoice != '0');
}
