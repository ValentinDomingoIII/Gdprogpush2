#include "level.h"

void displayLevelup(Player* player, int nRune)
{
    printf("\n\t\t\t\t\t\t\tLEVEL UP\n\n");
    printf("\t\t\t\t\t\t\t[1] Level up HEALTH\t[4] Level up STRENGTH\n");
    printf("\t\t\t\t\t\t\t[2] Level up ENDURANCE\t[5] Level up INTELLIGENCE\n");
    printf("\t\t\t\t\t\t\t[3] Level up DEXTERITY\t[6] Level up FAITH\n");

    printf("\n\t\t\t\t\t\t\t\t\t[0] BACK\n");
    printf("\n\t\t\t\t\t\t\t\x1b[38;5;11m Runes:\x1b[0m%d\n\n", player->nRunes);
    printf("\n\t\t\t\t\t\t\tLevel up cost: %d\n", nRune);
    printf("\n\t\t\t\t\t\t\tINPUT: ");
}

void processlevelup(Player* player) {
    char cChoice, cChoice2;
    int nRune = (player->nLevel * 100) / 2;

    do {
        nRune = (player->nLevel * 100) / 2;
        displayLevelup(player, nRune);
        scanf(" %c", &cChoice);

        switch (cChoice) {
            case '1':
                if (player->sStats.nHealth >= 50) {
                    printf("\nHealth is maxed out at %d", player->sStats.nHealth);
                } else {
                    printf("\nLevel up Health?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nHealth++;
                        printf("\nHealth increased to %d", player->sStats.nHealth);
                    }
                }
                break;

            case '2':
                if (player->sStats.nEndurance >= 50) {
                    printf("\nEndurance is maxed out at %d", player->sStats.nEndurance);
                } else {
                    printf("\nLevel up Endurance?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nEndurance++;
                        printf("\nEndurance increased to %d", player->sStats.nEndurance);
                    }
                }
                break;

            case '3':
                if (player->sStats.nDexterity >= 50) {
                    printf("\nDexterity is maxed out at %d", player->sStats.nDexterity);
                } else {
                    printf("\nLevel up Dexterity?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nDexterity++;
                        printf("\nDexterity increased to %d", player->sStats.nDexterity);
                    }
                }
                break;

            case '4':
                if (player->sStats.nStrength >= 50) {
                    printf("\nStrength is maxed out at %d", player->sStats.nStrength);
                } else {
                    printf("\nLevel up Strength?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nStrength++;
                        printf("\nStrength increased to %d", player->sStats.nStrength);
                    }
                }
                break;

            case '5':
                if (player->sStats.nIntelligence >= 50) {
                    printf("\nIntelligence is maxed out at %d", player->sStats.nIntelligence);
                } else {
                    printf("\nLevel up Intelligence?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nIntelligence++;
                        printf("\nIntelligence increased to %d", player->sStats.nIntelligence);
                    }
                }
                break;

            case '6':
                if (player->sStats.nFaith >= 50) {
                    printf("\nFaith is maxed out at %d", player->sStats.nFaith);
                } else {
                    printf("\nLevel up Faith?\n");
                    printf("[1] Yes [2] No: ");
                    scanf(" %c", &cChoice2);
                    if (cChoice2 == '1' && runemath(player)) {
                        player->sStats.nFaith++;
                        printf("\nFaith increased to %d", player->sStats.nFaith);
                    }
                }
                break;

            case '0':
                clear();  // Assuming clear() is a function to clear the screen
                break;

            default:
                printf("\nInvalid choice. Please select a valid option.\n");
                break;
        }
    } while (cChoice != '0');
}
