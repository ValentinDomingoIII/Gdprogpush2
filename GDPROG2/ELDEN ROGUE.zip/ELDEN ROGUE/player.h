#pragma once
#include "structures.h"

#include "title.h"
#include "character_creation.h"
#include "shop.h"

void resetInventory(Player* pPlayer);
void giveWeapon(Player* pPlayer);
 void initializePlayer();